# vue-router-next [![CircleCI](https://img.shields.io/circleci/project/vuejs/vue-router/next.svg?maxAge=2592000)](https://circleci.com/gh/vuejs/vue-router/tree/next)

`vue-router` for Vue 2.0.

This is still work in progress. There are numerous breaking changes from 0.7.x and docs are lacking - the best way to get started is checking out the examples.

``` bash
npm install

# serve examples at localhost:8080
npm run dev

# build dist files
npm run build
```
