/**
 * Created by superman on 17/2/16.
 */

export default {
    repo_list: '/user/repos'
}