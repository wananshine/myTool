<template>
	<div class="foot-wrap">
		<nav class="foot-nav">
			<a class="nav-cell">搜索</a>
			<a class="nav-cell">分类</a>
			<a class="nav-cell">购物车</a>
			<a class="nav-cell">我的</a>
		</nav>
	</div>
</template>
<style scoped lang="less">
	@import (reference) url(../../assets/css/cost.less);
	.foot-wrap{
		.por;
		.hid;
		.px2rem(height, 49);
	}
</style>
<script type="text/javascript">
	export default{
		name: "",
		data(){
			return{

			}
		}
	}
</script>