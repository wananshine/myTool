export default new Vue();
