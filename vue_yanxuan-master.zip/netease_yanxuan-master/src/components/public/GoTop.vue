<template>
    <Back-top :height="100" :bottom="56" :right="10">
        <div class="top"></div>
    </Back-top>
</template>
<script>
export default {
}
</script>
<style scoped>
    .top{
        border-radius: 2px;
        width: 1.09333rem;
    height: 1.09333rem;
    background-image: url(http://yanxuan.nosdn.127.net/hxm/yanxuan-wap/p/20161201/style/img/icon-normal/goToTop-7a19216f77.png);
    background-size: 1.09333rem 1.09333rem;
    }
</style>
</style>
