<template>
  <div>
      <no-list></no-list>
  </div>
</template>
<script>
import noList from './NoList'
export default {
  name: 'mylistall',
  components: {
    noList
  }
}
</script>
<style>

</style>
