<template>
  <div>
      <div class="container" >
        <div class="img" ></div>
        <div class="txt" >还没有任何订单呢</div>
     </div>
  </div>
  
</template>
<script>

</script>
<style scoped>
 .container {
    position: absolute;
    top: -.66667rem;
    right: 0;
    bottom: 0;
    left: 0;
    height: 4rem;
    margin: auto;
    text-align: center;
}
.img {
    background-image: url(http://yanxuan.nosdn.127.net/hxm/yanxuan-wap/p/20161201/style/img/icon-normal/noOrder-88b37a58f6.png);
}
 .img {
    display: inline-block;
    vertical-align: middle;
    width: 3.30667rem;
    height: 3.30667rem;
    margin-bottom: .10667rem;
    background-size: 3.30667rem 3.30667rem;
    background-position: center center;
    background-repeat: no-repeat;
}
.txt {
    font-size: .37333rem;
    line-height: 1;
    color: #999;
}
</style>
