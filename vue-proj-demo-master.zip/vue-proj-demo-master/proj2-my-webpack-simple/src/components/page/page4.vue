<template>
  <div class="page">
    <h1>page4.vue</h1>
    <router-link to="/page4/child1" >link1</router-link>
	<router-link to="/page4/child2" >link2</router-link>
	<hr>
	<router-view></router-view>
  </div>
</template>