<template>
  <div class="page">
    <h1>$route.params.id: {{$route.params.id}}</h1>
  </div>
</template>