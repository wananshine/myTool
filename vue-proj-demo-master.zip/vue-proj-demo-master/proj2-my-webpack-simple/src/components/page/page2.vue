<template>
  <div class="page">
    <h1>page2.vue</h1>
  </div>
</template>