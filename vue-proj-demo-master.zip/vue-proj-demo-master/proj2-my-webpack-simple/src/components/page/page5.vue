<template>
  <div class="page">
    <h1>page5.vue</h1>
  </div>
</template>