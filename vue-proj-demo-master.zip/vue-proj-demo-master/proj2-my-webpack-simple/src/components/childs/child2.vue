<template>
  <div class="child">
    <h1>child2.vue</h1>
  </div>
</template>