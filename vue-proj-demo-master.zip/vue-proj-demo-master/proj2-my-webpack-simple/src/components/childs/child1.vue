<template>
  <div class="child">
    <h1>child1.vue</h1>
  </div>
</template>