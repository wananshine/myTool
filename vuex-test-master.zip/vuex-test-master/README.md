# vuex-test

> 一个非常简单的vuex todolist 小栗子

## Build Setup

``` bash
# 安装依赖
npm install

# 启动项目 localhost:8080
npm run dev

# 打包项目
npm run build

```
## Tips

对于vuex的module两种写法里面也包含了
todo是复杂写法
login是简单写法
