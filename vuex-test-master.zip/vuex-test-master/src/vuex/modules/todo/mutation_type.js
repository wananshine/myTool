/**
 * Created by admin on 2017/1/12.
 */

export const ADD_TODO = 'ADD_TODO';
export const DONE_TODO = 'DONE_TODO';
export const SELECT_TYPE = 'SELECT_TYPE';
