<template>
  <div class="wrapper">
    <h1>暂未开发</h1>
    
  </div>
</template>

<script>
export default {

}
</script>

<style lang="stylus" scoped>
.wrapper
  height 10rem
  width 10rem
</style>
