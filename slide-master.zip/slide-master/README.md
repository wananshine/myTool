# slide
mobile slide page with avalon

[introduction](http://segmentfault.com/a/1190000003871349)

[preview](http://v.youku.com/v_show/id_XMTM2MjExNTM5Ng==.html)
