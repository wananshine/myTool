<template>
  <div id="down">
      这是下载页面啦啦啦啦啊。。。。
  </div>
</template>

<script>
export default {
  name: 'down'
}
</script>

<style>

</style>
