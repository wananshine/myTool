define(function(require) {
  return 'i';
})