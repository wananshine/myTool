define(function(require){
  var e = require('./e')
  return e
})