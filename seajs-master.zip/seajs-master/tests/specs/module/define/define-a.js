define('define-a', [], function(require, exports) {
  exports.name = 'a'
});
