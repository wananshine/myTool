define({ name: 'c' })
