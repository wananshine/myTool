
global.JSON = global.JSON || { fake: true };
