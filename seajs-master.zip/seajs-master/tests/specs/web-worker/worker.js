console.log("Worker Up!")
console.log(location)
importScripts("../../../dist/sea.js");

seajs.use("./tests");
