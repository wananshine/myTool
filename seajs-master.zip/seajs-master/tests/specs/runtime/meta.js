define('./meta', [
  'multi-circular'
])

