define('e', function() {
  return 'e';
})