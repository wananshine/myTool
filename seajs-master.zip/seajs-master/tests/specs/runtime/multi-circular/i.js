define('i', [], function(require) {
  return 'i';
})